console.log("hola mundo:)")
            console.log("ancho:" + window.innerWidth)
            let par;
            par = document.getElementById("parrafito") 
           if (window.innerWidth <700) {
            par.innerHTML = "menor a 700 px" 
           }
           else {
            par.inner = "mayor o igual a 700";
        }
        let captura;
        function setup() {
            createCanvas(800, 800);
            noCursor();
            captura = createCapture(VIDEO);
            captura.hide();
          }
          
          function draw() {
            background(200,200,80);
            image(captura, 0 ,0, 300, 300);
            ellipse(mouseX,mouseY, 100,100);
          }